

export const peaceTrackList = [
    {
        track: "Magic Island",
        trackDesc:'',
        trackAudioSrc:'https://res.cloudinary.com/dsegbjat2/video/upload/v1700850332/peace/magic-island-175480_wyofbx.mp3',
        trackImgSrc: "https://images.pexels.com/photos/2196602/pexels-photo-2196602.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
    },

]    
